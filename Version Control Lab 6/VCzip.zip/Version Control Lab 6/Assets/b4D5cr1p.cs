using System;
using UnityEngine;
public class b4D5cr1p : MonoBehaviour 
{
  public float maxX;                         // Maximum distance can be travelled in the axis-X
  public float maxY;                         // Maximum distance can be travelled in the axis-Y
  public float maxZ;                         // Maximum distance can be travelled in the axis-Z   
  private Vector3 newPosition;               // We can move to a new position
  public int counter = 0;                    // Counts the no.of moves 
  private bool canMove = true;               // Tell we can move or not

  void Update() 
  {
    if (Input.GetMouseButtonDown(0)) 
    { 
       DoTheMove();
    }
  }

  private void DoTheMove()                   // Codes To move
  {
   
    if (canMove)                             // Moves in all the axes
    {
      newPosition = new Vector3
      ( UnityEngine.Random.value > 0.5f ? UnityEngine.Random.Range(-maxX, maxX) : transform.position.x,
        UnityEngine.Random.value > 0.5f ? UnityEngine.Random.Range(-maxY, maxY) : transform.position.y,
        UnityEngine.Random.value > 0.5f ? UnityEngine.Random.Range(-maxZ, maxZ) : transform.position.z );
      
       transform.position = newPosition;      // Transform the postition to the new position
      Debug.Log("We moved!");                 // String that says "We Moved"
      counter++;                              // Adds the count
      if
        (counter > 10) canMove = false;       // Stop moving after it counts 10

    }
    else 
    {
       Debug.LogWarning("Can't move anymore!"); 
    }
  }

  public void ResetCounter()                   // Resets the counter 
  {
    counter = 0;                               // Counter starts from 0
    canMove = true;                            // Start moving when it is in 0
  }

}
